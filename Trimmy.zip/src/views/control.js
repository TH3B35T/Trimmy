var hls_base = "https://hlsdvr.vmclouds.co.uk/hls/";
//choose second part of hostname. E.g. mekameleen out of dvr.mekameleen.tv
//link is thus hls_base + "Mekameleen.m3u8"
var hls_src = hls_base + + window.location.hostname.split('.')[1].toLowerCase().replace(/^\w/, (c) => c.toUpperCase()) ;
//var chunkName = "input_stream-"; //{0}.ts // only used if finding chunk 0 on client side, which we're not doing anymore
var staticOffset = 16; //seconds, average difference between channel clock and time on play. Function of latency in path (Studio->StreamServer->DVR) 
var video = document.getElementById('mainVid');
var player = {};

let slider = document.getElementById('slider');

let video_size = {'w': 0, 'h': 0};
let time_start = 0;
let time_end = 1;
let startPicker = {};
let endPicker = {};
let timebase = new Date(new Date()-86400*1000);
let firstplay = true;

$(function() {
	console.log('Loaded DOM.');
	// what is this?
	$.modal.defaults = {modalClass: "modality"}
	
	// initialization
	player = initPlayer(video, hls_src);
	

	$("#mute_toggle").click(function (){
		$(video).prop('muted', !$(video).prop('muted'));
	});

	// slider creation after video loads
	$(video).bind("loadedmetadata", function (e) {
		video_size = {'w': this.videoWidth, 'h': this.videoHeight};
		console.log('Loaded: ', e.target.currentTime)
		$('.hide_until_load').removeClass('hidden');
		
		noUiSlider.create(slider, {
			start: [0, this.duration],
			connect: true,
			range: {
				'min': 0,
				'max': this.duration
			}/*,
			pips: {
				mode: 'steps',
				stepped: true,
				density: 60
			}*/
		});
		// set sliders range according to video duration
		slider.noUiSlider.on('update', (range)=>{
			update_slider_fields(range);
		});
		// how this function work without parameter?
		update_slider_fields();
		}).bind('loadeddata', function(e) {
		// noinspection JSIgnoredPromiseFromCall
			e.target.play();  // start playing
			}).on('pause', (e)=>{
				console.log('Paused: ', e.target.currentTime)
			}).on('play', (e)=>{
				console.log('Played: ', e.target.currentTime)
				console.log('Duration: ', e.target.duration)
				if (firstplay) {
					// some calc for time!!??
					timebase = new Date(new Date()-(e.target.duration+staticOffset)*1000);
					console.log("Timebase:",timebase);
					firstplay = false;
				}
			});

	//init pickers to update hidden fields
	Picker.setDefaults({controls: true, inline: true, format: 'HH:mm:ss', rows: 3, pick: (e)=>{}});
	startPicker = new Picker($('.stest')[0], {container: '.start-picker'});
	endPicker = new Picker($('.stest')[1], {container: '.end-picker'});
	//bind hidden fields to update visible ones
	$('.stest').on('change', function(e) {
		set_slider();
	});
	
	// $('.slider_control').on('change', (e)=>{
		// set_slider();
	// });	

	
	//activate red time tracker
	$('.slider_time_pos').mousedown((e)=>{
		let ele = e.target;
		let last_pos = e.clientX;
		let last_offest = ele.offsetLeft;
		
		function mup(e, ele){
			console.log('up');
			document.onmousemove = null;
			document.onmouseup = null;

			let delta = e.clientX - last_pos;
			console.log('Delta:', delta);
			//last_pos = e.clientX;
			let total_percent = (last_offest+delta)/ele.parentElement.offsetWidth;
			console.log(total_percent);
			player.currentTime(video.duration * total_percent);
		}
		function mmov(e, ele){
			let delta = e.clientX - last_pos;
			let total_percent = (last_offest+delta)/ele.parentElement.offsetWidth;
			$(ele).css("left", 100*total_percent + "%");
			$(".current_time").text(clockTime(video.duration * total_percent));
		}
		document.onmousemove = (e)=>{mmov(e, ele)};
		document.onmouseup = (e)=>{mup(e, ele)};
	});
});


function initPlayer(el, src) {
	var x = videojs(el, {
		source: {
			src: src,
			type: "application/x-mpegURL"
		}
	   });
	x.src({type: "application/x-mpegURL", src: src})
	x.dvr();
	
	return x;
}
// what does this func. do?
function clockTime(s) {
	var t = new Date(timebase);
	return t.addSeconds(s).toString("hh:mm:ss tt");
}
// what does this func. do?
function unitsFromSeconds(s) {
	return (new Date).clearTime()
          .addSeconds(s)
          .toString('H:mm:ss');
}

function update_slider_fields(range){
	if(!range || range.length < 2)
		return;
	// document.querySelectorAll('.slider_control').forEach(function(input) {
		// // noinspection JSUndefinedPropertyAssignment
		// input.value = range[input.dataset.pos];
	// });
	time_start = parseFloat(range[0]);
	time_end = parseFloat(range[1]);
	$('#durationLabel').text(unitsFromSeconds((range[1]-range[0])));
	startPicker.setDate((new Date(timebase)).addSeconds(range[0]));
	endPicker.setDate((new Date(timebase)).addSeconds(range[1]));
}

function set_slider(vals){
	//let vals = [];
	// document.querySelectorAll('.slider_control').forEach(function(input) {
		// vals.push(input.value)
	// });
	if (!vals)
		vals = [(startPicker.getDate()-timebase)/1000 , (endPicker.getDate()-timebase)/1000];
	
	
	console.log(vals);
	slider.noUiSlider.set(vals); //this triggers update_slider_fields(), recursively setting the pickers
}

// some important comments should be here!
function extractSequence(cb) {
	player.pause();
	var current = player.currentTime();
	function seq(t, callback) {
		player.on('timeupdate', function() {
			player.off('timeupdate');
			var cue = player.textTracks()[0].activeCues[0].value;
			var seq = cue.uri.substring(cue.uri.lastIndexOf('/')+1); //e.g. input_stream-211574.ts
			var ss = t - cue.start; //how many seconds into clip to cut
			return callback({segment: seq, time: ss});
		})
		player.currentTime(t);
	}
	var clip = [];
	seq(time_start, function(seg) {
		// // seg = {segment: "input_stream-343.ts", time: 4.81}
		//var segN = parseInt(seg.segment.replace(chunkName, '').replace('.ts'));
		//clip.push({segment: segN, time: 0});
		clip.push(seg);
		seq(time_end, function(seg) {
			clip.push(seg);
			cb({seq: clip, duration: time_end-time_start});
		})
	})
}

function reset_toggle(){
	console.log('looping back to section start');
	player.currentTime(time_start);
	video.play();
}

function pause_toggle(){
	console.log('toggle play');
	if(video.paused){
		video.play().finally(()=>{$(".play_toggle").html('&#10074;&#10074;')});
	}else{
		video.pause();
		$(".play_toggle").html('&#9654;')
	}
}

function end_toggle(){
	console.log('looping back last 5 seconds');
	player.currentTime(time_end - 5);
	video.play();
}

function copyStart(){
	var t = player.currentTime();
	console.log('Current playtime:', player.currentTime());
	set_slider([t, time_end]);
}

function copyEnd(){
	var t = player.currentTime();
	console.log('Current playtime:', player.currentTime());
	set_slider([time_start, t]);
}

function end_toggle(){
	console.log('looping back last 5 seconds');
	player.currentTime(time_end - 5);
	video.play();
}

function update(){
	//loop in highlighted section
	//do not load live stream by staying away from final chunk
	if (video.currentTime < time_start)
		player.currentTime(time_start);
	if (video.currentTime > time_end)
		//player.pause();
		player.currentTime(time_start);
	
	//move red slider to correct position if not being dragged
	if ($('.slider_time_pos:active').length < 1) {
		let complete_percent = 100 * (video.currentTime / video.duration);
		$(".slider_time_pos").css("left", complete_percent + "%");
		//update clock
		$(".current_time").text(clockTime(video.currentTime));
	}
	
	
	
	// //update ffmpeg command
	// let ts = (time_start?time_start.toFixed(2):0);
	// let te = (time_end?time_end.toFixed(2):0);
	// let mpeg = 'ffmpeg -ss '+ts+' -i "'+filename+'" -movflags faststart -t '+(te-ts).toFixed(4)+' ';
	// mpeg+='-c:a copy out.mp4';
	// if($('.ffmpeg').text() !== mpeg) {
		// $('.ffmpeg').text(mpeg);
	// }
	
	//requestAnimationFrame(update.bind(this)); // Tell browser to trigger this method again, next animation frame.
}

function start() {
	player.play().then(()=>player.currentTime(1));
	$('.start_toggle').remove();
	setInterval(update, 300);
}

function push(data, callback) {
	//find a way to detect previous clip in playlist without changing playtime (search?)
	$.ajax
    ({
        type: "POST",
        url: '/pull/dvr',
        dataType: 'json',
        data: JSON.stringify(data),
		contentType: "application/json; charset=utf-8",
        success: (res) => {callback(null)},
		error: (xhr, status, error)=>{callback({status: status, error: error})},
        failure: (res) => {callback({error: "Failed"})}
    })
}

function process_trim() {
	//show modal with (loading)
	$('#statusModal>h5').text("Extracting clip...");
	$('#statusModal>h4').hide();
	$('#statusModal').modal({fadeDuration: 100,clickClose: false, showClose: false});
	
	//extractSequence
	extractSequence((data)=> {
		//set modal to (uploading)
		$('#statusModal>h5').text("Uploading to server...");
		//push as ajax
		push(data, (err)=>{
			//show modal with result (Success: Redirecting to homepage) / (Error: here is info. Retry if you like)		
			if (err) {
				$.modal.close();
				$('#statusModal>h5').text("Problem while pushing to server. If problem persists, contact ammar@vmclouds.co.uk");
				$('#statusModal>h4').text(JSON.stringify(err));
				$('#statusModal>h4').show();
			} 
			else {
				$('#statusModal>h4').text("Complete!").show();
				$('#statusModal>h5').text("Server is currently processing clip. You'll be redirected to the results page shortly.");
				setTimeout(()=>{window.location="/"},3000)
			}
		})
	})
}
