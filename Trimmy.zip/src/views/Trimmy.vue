<template>
  <v-row align="center" justify="center">
    <v-col cols="12" align="center" justify="center">
      <!-- video player section -->
      <v-row>
        <v-col cols="12" align="center" justify="center">
          <v-card :width="videoWidth" color="primary">
            <video
              autoplay
              muted
              width="100%"
              controls
              id="mainVid"
              ref="videoPlayer"
              class="video-js"
            ></video>
          </v-card>
        </v-col>
      </v-row>
      <!--end video player section -->
      <!-- sliders section -->
      <v-row>
        <v-col cols="12" align="center" justify="center">
          <v-card flat color="transparent">
            <v-card-text>
              <v-row class="justify-center" md="auto">
                <v-col class="px-4 my-0 pa-0">
                  <!-- video hours slider -->
                  <v-slider
                    class="font-weight-bold"
                    color="success"
                    :tick-labels="ticksLabelsHoursAuto"
                    :rules="[
                      (v) => v <= ticksLabelsHoursAuto.length - zoomRange - 1,
                    ]"
                    step="1"
                    ticks="always"
                    tick-size="3"
                    v-model="videoSliderH"
                    :max="ticksLabelsHoursAuto.length - 1"
                  >
                  </v-slider>
                  <!-- end video hours slider -->
                  <!-- zoom level options -->
                  <v-radio-group
                    label="Zoom Range"
                    v-model="zoomRange"
                    row
                    class="justify-center"
                  >
                    <v-spacer></v-spacer>
                    <v-radio
                      label="4 Hours"
                      value="4"
                      color="primary"
                    ></v-radio>
                    <v-spacer></v-spacer>
                    <v-radio
                      label="3 Hours"
                      value="3"
                      color="secondary"
                    ></v-radio>
                    <v-spacer></v-spacer>
                    <v-radio
                      label="2 Hours"
                      value="2"
                      color="success"
                    ></v-radio>
                    <v-spacer></v-spacer>
                    <v-radio label="1 Hour" value="1" color="warning"></v-radio>
                    <v-spacer></v-spacer>
                    <v-radio
                      label="30 Minutes"
                      value="0.5"
                      color="error"
                    ></v-radio>
                    <v-spacer></v-spacer>
                  </v-radio-group>
                  <!-- end zoom level options -->
                  <!-- video player slider after hours+zoom -->
                  <v-row>
                    <span class="ma-1 primary--text font-weight-bold">{{
                      secondsToTimeString(minSlider)
                    }}</span>
                    <v-slider
                      thumb-label
                      :thumb-size="60"
                      v-model="videoSlider"
                      :max="maxSlider"
                      :min="minSlider"
                    >
                      <template v-slot:thumb-label="{ value }">
                        {{ secondsToTimeString(value) }}
                      </template>
                    </v-slider>
                    <span class="ma-1 secondary--text font-weight-bold">{{
                      secondsToTimeString(maxSlider)
                    }}</span>
                  </v-row>
                  <!--end video player slider after hours+zoom -->
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </v-col>
      </v-row>
      <!-- end sliders section -->
      <!-- pickers body section -->
      <v-container>
        <!-- mobile time picker doesn't look good "More work needed"-->
        <v-col class="d-flex d-sm-none" cols="11" sm="5">
          <v-menu
            ref="inMenu"
            v-model="inMenuPicker"
            :close-on-content-click="false"
            :return-value.sync="inTime"
            transition="scale-transition"
            offset-y
            max-width="290px"
            min-width="290px"
          >
            <template v-slot:activator="{ on, attrs }">
              <v-text-field
                v-model="inTime"
                label="In Time"
                prepend-icon="mdi-clock-time-four-outline"
                readonly
                v-bind="attrs"
                v-on="on"
              ></v-text-field>
            </template>
            <v-time-picker
              v-if="inMenuPicker"
              v-model="inTime"
              @change="setInTimePicker"
              full-width
              format="24hr"
              use-seconds
              @click:second="$refs.inMenu.save(inTime)"
            ></v-time-picker>
          </v-menu>
        </v-col>
        <v-col class="d-flex d-sm-none" cols="11" sm="5">
          <v-menu
            ref="outMenu"
            v-model="outMenuPicker"
            :close-on-content-click="false"
            :return-value.sync="outTime"
            transition="scale-transition"
            offset-y
            max-width="290px"
            min-width="290px"
          >
            <template v-slot:activator="{ on, attrs }">
              <v-text-field
                v-model="outTime"
                label="Out Time"
                prepend-icon="mdi-clock-time-four-outline"
                readonly
                v-bind="attrs"
                v-on="on"
              ></v-text-field>
            </template>
            <v-time-picker
              v-if="outMenuPicker"
              v-model="outTime"
              @change="setOutTimePicker"
              full-width
              format="24hr"
              use-seconds
              @click:second="$refs.outMenu.save(outTime)"
            ></v-time-picker>
          </v-menu>
        </v-col>
        <!-- end mobile time picker -->

        <!-- large screens time picker -->
        <v-row align="center" justify="center" dense>
          <v-col cols="5" align="center" justify="center">
            <v-card class="d-none d-sm-block" outlined color="transparent">
              <v-card-subtitle class="primary--text text-h6"
                >In Time:
                <v-btn color="success" class="mx-3" fab @click="setInTime()">
                  <v-icon large class="mr-2">
                    {{ icons.mdiLogin }}
                  </v-icon>
                </v-btn>
              </v-card-subtitle>
              <v-time-picker
                color="success"
                @change="setInTimePicker"
                class="my-1"
                format="24hr"
                use-seconds
                v-model="inTime"
              ></v-time-picker>
            </v-card>
          </v-col>
          <v-col cols="2" align="center" justify="center">
            <v-row>
              <v-flex
                class="primary--text text-h6"
                v-if="!firstplay"
                align-center
              >
                Video Player Time:
                {{ secondsToTimeString(playerCurrentTime) }}
              </v-flex>
            </v-row>
            <v-row>
              <v-flex v-if="outTime" align-center>
                <p class="secondary--text font-weight-bold">
                  Clip Duration Is:
                  {{
                    secondsToTimeString(
                      timeStringToSeconds(outTime) - timeStringToSeconds(inTime)
                    )
                  }}
                </p>
              </v-flex>
            </v-row>
            <v-spacer></v-spacer>
            <v-row class="d-sm-none d-md-flex my-5">
              <v-flex text-xs-center align-center>
                <v-btn
                  color="primary"
                  elevation="6"
                  raised
                  rounded
                  x-large
                  :disabled="
                    inTime == null || outTime == null || !trimButtonEnable
                  "
                  @click="trimClip(inTime, outTime)"
                >
                  <v-icon medium left>
                    {{ icons.mdiContentCut }}
                  </v-icon>
                  Trim
                </v-btn>
              </v-flex>
              <v-flex text-xs-center align-center class="mx-5 my-5">
                <v-dialog v-model="dialog" width="800px">
                  <template v-slot:activator="{ on, attrs }">
                    <v-btn
                      class="mx-2"
                      rounded
                      bottom
                      right
                      dark
                      v-bind="attrs"
                      v-on="on"
                      color="secondary"
                    >
                      <v-icon dark>
                        {{ icons.mdiFormatListBulletedSquare }}
                      </v-icon>
                    </v-btn>
                  </template>
                  <v-card max-width="750" class="mx-auto">
                    <v-toolbar color="primary" dark>
                      <v-toolbar-title class="white--text"
                        >Clips List
                      </v-toolbar-title>
                      <v-spacer></v-spacer>
                      <v-btn icon large click="clearLocalStorage" color="error">
                        <v-icon large dark>
                          {{ icons.mdiDeleteAlertOutline }}
                        </v-icon>
                      </v-btn>
                    </v-toolbar>
                    <v-list three-line>
                      <v-list-item v-for="file in fileList" :key="file.index">
                        <v-list-item-avatar>
                          <v-icon class="primary">
                            {{ icons.mdiPlayCircle }}
                          </v-icon>
                        </v-list-item-avatar>
                        <v-list-item-content>
                          <v-list-item-title
                            class="black--text font-weight-medium"
                            v-text="
                              `ID: ` +
                              file.index +
                              `, Status: ` +
                              file.fileDetials.status
                            "
                          >
                          </v-list-item-title>
                          <v-list-item-subtitle
                            v-text="file.fileDetials.displayName"
                          ></v-list-item-subtitle>
                        </v-list-item-content>
                        <v-list-item-action>
                          <v-btn
                            @click="deleteFile(fileList.indexOf(file), file)"
                            icon
                          >
                            <v-icon color="error">{{
                              icons.mdiDeleteAlertOutline
                            }}</v-icon>
                          </v-btn>
                        </v-list-item-action>
                        <v-list-item-action>
                          <v-btn
                            :loading="
                              file.fileDetials.status != `Upload Complete`
                            "
                            icon
                          >
                            <v-icon color="primary">{{
                              icons.mdiDownload
                            }}</v-icon>
                          </v-btn>
                        </v-list-item-action>
                        <v-list-item-action>
                          <v-btn
                            :disabled="
                              file.fileDetials.status != `Upload Complete`
                            "
                            @click="downFile(file.fileDetials.filename)"
                            icon
                          >
                            <v-icon color="primary">{{
                              icons.mdiDownload
                            }}</v-icon>
                          </v-btn>
                        </v-list-item-action>
                      </v-list-item>
                    </v-list>
                  </v-card>
                </v-dialog>
              </v-flex>
            </v-row>
          </v-col>
          <v-col cols="5" align="center" justify="center">
            <v-card class="d-none d-sm-block" outlined color="transparent">
              <v-card-subtitle class="primary--text text-h6"
                >Out Time
                <v-btn
                  color="error"
                  class="mx-3"
                  fab
                  :disabled="
                    inTimeSeconds == 0 || playerCurrentTime < inTimeSeconds
                  "
                  @click="setOutTime"
                >
                  <v-icon large class="" style="transform: rotate(180deg)">
                    {{ icons.mdiLogin }}
                  </v-icon>
                </v-btn>
              </v-card-subtitle>
              <v-time-picker
                :allowed-hours="validPickH"
                :allowed-minutes="validPickM"
                :allowed-seconds="validPickS"
                color="error"
                class="my-1"
                format="24hr"
                use-seconds
                v-model="outTime"
                @change="setOutTimePicker"
                :disabled="inTime === null"
              ></v-time-picker>
            </v-card>
          </v-col>
        </v-row>
        <!-- end large screens time picker -->
      </v-container>
      <!-- end pickers body section -->
      <!-- button and time labels between time pickers -->
      <v-row>
        <v-col
          cols="12"
          align="center"
          justify="center"
          class="my-5 d-none d-sm-flex d-md-none"
        >
          <v-flex text-xs-center align-center>
            <v-btn
              color="primary"
              elevation="6"
              raised
              rounded
              x-large
              :disabled="inTime == null || outTime == null || trimButtonEnable"
              @click="trimClip()"
            >
              <v-icon medium left>
                {{ icons.mdiContentCut }}
              </v-icon>
              Trim
            </v-btn>
          </v-flex>
          <v-dialog v-model="dialog" width="800px">
            <template v-slot:activator="{ on, attrs }">
              <v-btn
                class="mx-2"
                fab
                bottom
                right
                dark
                v-bind="attrs"
                v-on="on"
                color="secondary"
              >
                <v-icon dark>
                  {{ icons.mdiFormatListBulletedSquare }}
                </v-icon>
              </v-btn>
            </template>
            <v-card max-width="750" class="mx-auto">
              <v-toolbar color="primary" dark>
                <v-toolbar-title class="white--text"
                  >Clips List</v-toolbar-title
                >
                <v-spacer></v-spacer>
                <!-- <v-btn
                  icon
                  large
                  class="mx-5"
                  @click="clearLocalStorage"
                  color="error"
                >
                  <v-icon large dark>
                    {{ icons.mdiDeleteAlertOutline }}
                  </v-icon>
                </v-btn> -->
              </v-toolbar>
              <v-list two-line>
                <v-list-item v-for="file in fileList" :key="file.index">
                  <v-list-item-avatar>
                    <v-icon class="primary">
                      {{ icons.mdiPlayCircle }}
                    </v-icon>
                  </v-list-item-avatar>

                  <v-list-item-content>
                    <v-list-item-title
                      class="black--text"
                      v-text="`ID: ` + file.index"
                    >
                    </v-list-item-title>
                    <v-list-item-title
                      class="primary--text font-weight-medium"
                      v-text="`Status: ` + file.fileDetials.status"
                    >
                    </v-list-item-title>
                    <v-list-item-subtitle
                      v-text="file.fileDetials.displayName"
                    ></v-list-item-subtitle>
                  </v-list-item-content>
                  <v-list-item-action>
                    <v-btn
                      @click="deleteFile(fileList.indexOf(file), file)"
                      icon
                      class="mx-3"
                    >
                      <v-icon color="error">{{
                        icons.mdiDeleteAlertOutline
                      }}</v-icon>
                    </v-btn>
                  </v-list-item-action>
                  <v-list-item-action>
                    <v-btn
                      class="mx-3"
                      :loading="file.fileDetials.status != `Upload Complete`"
                      @click="downFile(file.fileDetials.filename)"
                      icon
                    >
                      <v-icon color="primary">{{ icons.mdiDownload }}</v-icon>
                    </v-btn>
                  </v-list-item-action>
                </v-list-item>
              </v-list>
            </v-card>
          </v-dialog>
        </v-col>
      </v-row>
      <!-- end button and time labels between time pickers -->
    </v-col>
    <!-- show messages for user after Trim request -->
    <v-snackbar v-model="snackbar" bottom color="primary">
      {{ snackbarMsg }}
      <template v-slot:action="{ attrs }">
        <v-btn color="white" text v-bind="attrs" @click="snackbar = false">
          Close
        </v-btn>
      </template>
    </v-snackbar>
    <!-- end show messages for user after Trim request -->
  </v-row>
</template>

<script>
import {
  mdiAlert,
  mdiContentCut,
  mdiLogin,
  mdiFormatListBulletedSquare,
  mdiPlayCircle,
  mdiDownload,
  mdiDeleteAlertOutline,
} from "@mdi/js";
import videojs, { browser } from "video.js";
// import noUiSlider from "nouislider";
import axios from "axios";

export default {
  computed: {
    // trying to keep looks good on different screens "mob is bad"
    videoWidth() {
      switch (this.$vuetify.breakpoint.name) {
        case "xs":
          return "98%";
        case "sm":
          return "98%";
        case "md":
          return "56%";
        case "lg":
          return "56%";
        case "xl":
          return "56%";
      }
    },
  },
  data() {
    return {
      indexList: [],
      fileList: [],
      dialog: false,
      snackbar: false,
      snackbarMsg: "",
      firstplay: true,
      inTime: null,
      inTimeSeconds: 0,
      outTime: null,
      outTimeSeconds: 0,
      inMenuPicker: false,
      outMenuPicker: false,
      videoSliderH: null,
      videoSlider: 0,
      zoomRange: "4",
      maxSlider: 0,
      minSlider: 0,
      trimButtonEnable: true,
      player: {},
      playerCurrentTime: 0,
      videoOptions: {
        // liveui: true,
        autoplay: true,
        controls: true,
        fluid: true,
        sources: [
          {
            src: "",
            type: "application/x-mpegURL",
          },
        ],
      },
      ticksLabelsHoursAuto: [],
    };
  },
  watch: {
    // change player current time based on slider value
    videoSlider(val) {
      this.player.currentTime(val);
      if (this.inTime != null) {
        if (val < this.timeStringToSeconds(this.inTime)) {
          this.outTime = null;
        }
      }
    },
    // change zoom level depending on selected range
    zoomRange(val) {
      this.minSlider = this.videoSlider;
      this.maxSlider = this.videoSlider + parseFloat(val) * 60 * 60;
    },
    // hours slider value limits to avoid selecting duration doesn't exist
    videoSliderH(val) {
      if (val >= this.ticksLabelsHoursAuto.length - this.zoomRange) {
        val = this.ticksLabelsHoursAuto.length - this.zoomRange - 1;
        this.videoSliderH =
          this.ticksLabelsHoursAuto.length - this.zoomRange - 1;
        this.videoSlider = val * 60 * 60;
        this.minSlider = this.videoSlider;
        this.maxSlider =
          this.videoSlider + parseFloat(this.zoomRange) * 60 * 60;
      } else {
        this.videoSlider = val * 60 * 60;
        this.minSlider = this.videoSlider;
        this.maxSlider =
          this.videoSlider + parseFloat(this.zoomRange) * 60 * 60;
      }
    },
    // auto update player current time as long as it plays.
    playerCurrentTime() {},
  },
  setup() {
    return {
      icons: {
        mdiAlert,
        mdiContentCut,
        mdiLogin,
        mdiFormatListBulletedSquare,
        mdiPlayCircle,
        mdiDownload,
        mdiDeleteAlertOutline,
      },
    };
  },
  mounted() {
    // checking my Host name to get right record and set page colors
    var myHostName = window.location.hostname
      .split(".")[1]
      .toLowerCase()
      .replace(/^\w/, (c) => c.toUpperCase());

    this.videoOptions.sources[0].src =
      "https://vmclouds.co.uk/" + myHostName + ".m3u8";

    // set page title
    document.title = "Trimmy";
    // check if we have local storage before to load requested files before
    if (localStorage.getItem("fileList"))
      this.fileList = [...JSON.parse(localStorage.getItem("fileList"))];

    this.player = this.initPlayer();
    // hours slider creation after video loads with values depending on total video duration
    this.$refs.videoPlayer.onloadedmetadata = function (e) {
      console.log("Video loaded duration: ", e.target.currentTime);
      this.ticksLabelsHoursAutoSet(e.target.currentTime);
      // setting hours slider to 0 hour to start at first hour
      this.videoSliderH = 0;
      this.firstplay = false;
    }.bind(this);
    // update player current time label each 250 ms
    window.setInterval(() => {
      this.playerCurrentTimeUpdate();
    }, 250);
    // auto check for ready trimmed clips to download each 5 seconds works for all fileList
    window.setInterval(() => {
      this.fileList.forEach((element) => {
        axios.get(`/api/getItem?id=${element.index}`).then((response) => {
          if (element.fileDetials.status != response.data.status) {
            element.fileDetials = response.data;
          }
        });
      });
    }, 5000);
  },

  methods: {
    // remove single clip from fileList and from local storage
    deleteFile(index, file) {
      axios
        .post(`/api/purgeItem`, `id=${file.index}`)
        .then((dvrResponse) => {
          console.log("this clip was delete", dvrResponse.data);
        })
        .catch((status, error) => callback({ status: status, error: error }));
      console.log(file.index);

      this.fileList.splice(index, 1);
      localStorage.setItem("fileList", JSON.stringify(this.fileList));
    },
    // open download page for ready clips
    downFile(filename) {
      window.open(`/storage/${filename}`);
    },
    // remove all clips from fileList & local storage
    clearLocalStorage() {
      this.fileList = [];
      localStorage.clear();
    },
    // dynamic hours slider value depending on total main video duration
    ticksLabelsHoursAutoSet(vidTime) {
      for (let i = 0; i <= Math.round(vidTime / 3600); i++) {
        this.ticksLabelsHoursAuto.push(i.toString());
      }
    },
    // update video player time label depending on player's current time
    playerCurrentTimeUpdate() {
      if (!this.firstplay) {
        if (this.player.currentTime() != undefined) {
          this.playerCurrentTime = this.player.currentTime();
        }
      }
    },
    // set inTime via green button from player current time seconds value
    setInTime() {
      this.player.pause();
      this.inTimeSeconds = this.playerCurrentTime;
      this.inTime = this.secondsToTimeString(this.inTimeSeconds);
    },
    // set outTime via red button from player current time seconds value
    setOutTime() {
      if (this.playerCurrentTime <= this.inTimeSeconds) {
        return;
      }
      this.player.pause();
      this.outTimeSeconds = this.playerCurrentTime;
      this.outTime = this.secondsToTimeString(this.outTimeSeconds);
    },
    // set inTime via green time picker depending on specific HH:MM:SS
    setInTimePicker() {
      this.player.currentTime(this.timeStringToSeconds(this.inTime));
      this.player.pause();
      this.inTimeSeconds = this.player.currentTime();
    },
    // set outTime via red time picker depending on specific HH:MM:SS
    setOutTimePicker() {
      this.player.currentTime(this.timeStringToSeconds(this.outTime));
      this.player.pause();
      this.outTimeSeconds = this.player.currentTime();
    },
    // change x seconds number to HH:MM:SS string
    secondsToTimeString(seconds) {
      return new Date(seconds * 1000).toISOString().substr(11, 8);
    },
    // change HH:MM:SS string to x seconds number
    timeStringToSeconds(time_string) {
      let arr = time_string.split(":");
      return +arr[0] * 60 * 60 + +arr[1] * 60 + +arr[2];
    },
    // sets video html with proper option to work
    initPlayer() {
      var x = videojs(this.$refs.videoPlayer, this.videoOptions);
      return x;
    },
    // extract sequence name and exact time needed on this sequence.
    // e.g.: get input_stream-211574.ts, after 2.465 seconds from it's start
    seq(t, callback) {
      this.player.on("timeupdate", () => {
        this.player.off("timeupdate");
        var activeClues = this.player.textTracks()[0].activeCues[0];
        var cue = activeClues.value;
        var seq = cue.uri.substring(cue.uri.lastIndexOf("/") + 1); //e.g. input_stream-211574.ts
        var ss = t - cue.start; //how many seconds into clip to cut
        return callback({ segment: seq, time: ss });
      });
      this.player.currentTime(t);
    },
    // get sequence detials and time for start and end for requested trim.
    // data is stored in clip array to be pushed later to backend
    extractSequence(cb) {
      this.player.pause();
      var clip = [];
      this.seq(parseFloat(this.inTimeSeconds), (seg) => {
        clip.push(seg);
        this.seq(parseFloat(this.outTimeSeconds), (seg) => {
          clip.push(seg);
          cb({
            seq: clip,
            duration: parseFloat(this.outTimeSeconds - this.inTimeSeconds),
          });
        });
      });
    },
    // Start trim process after setting inTime&outTime
    trimClip() {
      this.trimButtonEnable = false;
      console.log(
        "Trying to trim clip from: ",
        this.inTime,
        "To: ",
        this.outTime
      );
      this.extractSequence((data) => {
        this.snackbarMsg = "Sending detials to server...";
        this.snackbar = true;
        //push request
        this.push(data, (err) => {
          if (err) {
            this.snackbarMsg =
              "Problem while pushing to server. \n If problem persists, contact: \n support";
            this.snackbar = true;
            console.log(err);
          } else {
            this.snackbarMsg =
              "Server received your request.\n Server is currently processing clip, Check clips list later.";
            this.snackbar = true;
          }
        });
        this.dialog = true;
        this.trimButtonEnable = true;
      });
    },
    // push clip request to server, store index value onSuccess response
    push(data, callback) {
      axios
        .post("/pull/dvr", data)
        .then((dvrResponse) => {
          if (dvrResponse.data.status == "Success") {
            axios
              .get(`/api/getItem?id=${dvrResponse.data.data.index}`)
              .then((response) => {
                this.fileList.push({
                  index: dvrResponse.data.data.index,
                  fileDetials: response.data,
                });
                localStorage.setItem("fileList", JSON.stringify(this.fileList));
              });
          }
          callback(null);
        })
        .catch((status, error) => callback({ status: status, error: error }));
    },
    // End timePicker allow certian HH according to Start time picker hours to avoid 24 hour trim
    validPickH(h) {
      return h + 1 > Math.floor(this.timeStringToSeconds(this.inTime) / 3600);
    },
    // End timePicker allow certian MM according to Start time picker MM to avoid 24 hour trim
    // useless now
    validPickM(m) {
      return (
        m + 60 > Math.floor((this.timeStringToSeconds(this.inTime) % 3600) / 60)
      );
    },
    // End timePicker allow certian SS according to Start time picker SS
    // useless now
    validPickS(s) {
      return (
        s + 60 > Math.floor((this.timeStringToSeconds(this.inTime) % 3600) % 60)
      );
    },
  },
};
</script>

<style lang="scss">
@import "../../node_modules/video.js/dist/video-js.css";
</style>
